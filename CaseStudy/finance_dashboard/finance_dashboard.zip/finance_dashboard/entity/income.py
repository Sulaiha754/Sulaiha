class Income:
    def __init__(self, income_id, user_id, category_id, amount, date, description):
        self.income_id = income_id
        self.user_id = user_id
        self.category_id = category_id
        self.amount = amount
        self.date = date
        self.description = description
