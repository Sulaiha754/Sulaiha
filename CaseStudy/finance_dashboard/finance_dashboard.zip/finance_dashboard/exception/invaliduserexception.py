class InvalidUserException(Exception):
    pass
