import pyodbc
from entity.customer import Customer
from entity.account import SavingsAccount, CurrentAccount, ZeroBalanceAccount
from exception.insufficient_fund_exception import InsufficientFundException
from exception.overdraft_limit_exception import OverdraftLimitException
from exception.invalid_account_exception import InvalidAccountException

class BankServiceImpl:
    def __init__(self):
        self.accounts = []

    def create_account(self, customer, acc_type, balance):
        if acc_type.lower() == "savings":
            acc = SavingsAccount(balance, customer)
        elif acc_type.lower() == "current":
            acc = CurrentAccount(balance, customer)
        elif acc_type.lower() == "zerobalance":
            acc = ZeroBalanceAccount(customer)
        else:
            raise InvalidAccountException("Invalid account type.")
        self.accounts.append(acc)
        print(f"Account Created: {acc.account_number}")

    def get_account(self, acc_no):
        for acc in self.accounts:
            if acc.account_number == acc_no:
                return acc
        raise InvalidAccountException("Account not found.")

    def deposit(self, acc_no, amount):
        acc = self.get_account(acc_no)
        acc.balance += amount
        print(f"Deposited. New Balance: {acc.balance}")

    def withdraw(self, acc_no, amount):
        acc = self.get_account(acc_no)
        if hasattr(acc, 'withdraw'):
            acc.withdraw(amount)
        elif acc.balance >= amount:
            acc.balance -= amount
        else:
            raise InsufficientFundException("Insufficient balance.")
        print(f"New Balance: {acc.balance}")

    def get_balance(self, acc_no):
        acc = self.get_account(acc_no)
        print(f"Current Balance: {acc.balance}")

    def transfer(self, from_acc, to_acc, amount):
        sender = self.get_account(from_acc)
        receiver = self.get_account(to_acc)
        if sender.balance >= amount:
            sender.balance -= amount
            receiver.balance += amount
            print("Transfer successful.")
        else:
            raise InsufficientFundException("Insufficient funds.")

    def get_account_details(self, acc_no):
        acc = self.get_account(acc_no)
        print(acc)

    def list_accounts(self):
        for acc in self.accounts:
            print(acc)

    def calculate_interest(self, acc_no):
        acc = self.get_account(acc_no)
        if isinstance(acc, SavingsAccount):
            interest = acc.calculate_interest()
            print(f"Interest applied: {interest}, New Balance: {acc.balance}")
        else:
            print("Interest applicable only for Savings Account.")
