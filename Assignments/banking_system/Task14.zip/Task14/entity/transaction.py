class Transaction:
    def __init__(self, transaction_id=None, account_number=None, transaction_type=None, amount=0.0, transaction_date=None):
        self.transaction_id = transaction_id
        self.account_number = account_number
        self.transaction_type = transaction_type
        self.amount = amount
        self.transaction_date = transaction_date
