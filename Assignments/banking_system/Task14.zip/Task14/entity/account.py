class Account:
    def __init__(self, account_number=None, customer_id=None, account_type=None, balance=0.0, interest_rate=None, overdraft_limit=None):
        self.account_number = account_number
        self.customer_id = customer_id
        self.account_type = account_type
        self.balance = balance
        self.interest_rate = interest_rate
        self.overdraft_limit = overdraft_limit
        
