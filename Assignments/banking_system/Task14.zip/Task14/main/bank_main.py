import sys

sys.path.append('C:/Users/User/Desktop/Sulaiha/Assignments/banking_system/Task14')


from entity.customer import Customer
from dao.bank_impl import BankServiceImpl

def main():
    bank = BankServiceImpl()
    while True:
        print("\n1.Create\n2.Deposit\n3.Withdraw\n4.Balance\n5.Transfer\n6.Details\n7.List\n8.Interest\n9.Exit")
        ch = input("Choice: ")
        try:
            if ch == "1":
                fname = input("First Name: ")
                lname = input("Last Name: ")
                email = input("Email: ")
                phone = input("Phone: ")
                address = input("Address: ")
                acc_type = input("Account Type (Savings/Current/ZeroBalance): ")
                if acc_type.lower() == "zerobalance":
                    balance = 0
                else:
                    balance = float(input("Initial balance: "))
                cust = Customer(fname, lname, email, phone, address)
                bank.create_account(cust, acc_type, balance)

            elif ch == "2":
                acc = int(input("Account number: "))
                amt = float(input("Amount: "))
                bank.deposit(acc, amt)

            elif ch == "3":
                acc = int(input("Account number: "))
                amt = float(input("Amount: "))
                bank.withdraw(acc, amt)

            elif ch == "4":
                acc = int(input("Account number: "))
                bank.get_balance(acc)

            elif ch == "5":
                f = int(input("From Acc: "))
                t = int(input("To Acc: "))
                amt = float(input("Amount: "))
                bank.transfer(f, t, amt)

            elif ch == "6":
                acc = int(input("Account number: "))
                bank.get_account_details(acc)

            elif ch == "7":
                bank.list_accounts()

            elif ch == "8":
                acc = int(input("Enter Savings Account number: "))
                bank.calculate_interest(acc)

            elif ch == "9":
                print("Goodbye!")
                break

            else:
                print("Invalid choice.")
        except Exception as e:
            print("Error:", e)

if __name__ == "__main__":
    main()
