DB_CONFIG = {
    'server': 'SULAI\\MSS',
    'database': 'HMB',
    'trusted_connection': 'yes',
    'driver': '{ODBC Driver 17 for SQL Server}',
    'port': '61896'
    
}
