import pyodbc
from util.db_property_util import DB_CONFIG

def get_connection():
    conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={DB_CONFIG['server']};DATABASE={DB_CONFIG['database']};TRUSTED_CONNECTION={DB_CONFIG['trusted_connection']};PORT={DB_CONFIG['port']}"
    return pyodbc.connect(conn_str)
