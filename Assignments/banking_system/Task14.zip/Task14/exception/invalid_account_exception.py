# exception/invalid_account_exception.py

class InvalidAccountException(Exception):
    def __init__(self, message="Invalid account operation"):
        self.message = message
        super().__init__(self.message)
