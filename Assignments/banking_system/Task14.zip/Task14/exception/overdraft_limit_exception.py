class OverdraftLimitException(Exception):
    pass
