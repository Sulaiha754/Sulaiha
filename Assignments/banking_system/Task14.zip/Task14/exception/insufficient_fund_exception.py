class InsufficientFundException(Exception):
    pass
